<?php
namespace Elsnertech\Flashsale\Model\ResourceModel\FlashsaleProduct;

/**
 * FlashsaleProduct Collection
 *
 * @author Elsnertech
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * $_idFieldName variable
     *
     * @var string
     */
    protected $_idFieldName = 'id';
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init(
            \Elsnertech\Flashsale\Model\FlashsaleProduct::class,
            \Elsnertech\Flashsale\Model\ResourceModel\FlashsaleProduct::class
        );
    }
}
