<?php
/**
* Copyright © 2022 Elsner. All rights reserved.
*/

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::THEME,
    'frontend/1deelert/1deelert_theme',
    __DIR__
);
