var config = {
paths: {
        slick: 'js/slick'
    },
shim: {
    slick: {
        deps: ['jquery']
    }
},
map: {
        '*': {
            deelert: 'js/1deelert'
        }
    }
};