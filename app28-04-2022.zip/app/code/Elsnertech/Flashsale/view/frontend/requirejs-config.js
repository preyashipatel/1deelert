var config = {
    paths: {
        owlcarousel: "Elsnertech_Flashsale/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};