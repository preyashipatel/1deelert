<?php

namespace Elsnertech\Homeslider\Block\Adminhtml\Helper\Image;

class Required extends \Magento\Framework\Data\Form\Element\Image
{
    protected function _getDeleteCheckbox()
    {
        return '';
    }
}
