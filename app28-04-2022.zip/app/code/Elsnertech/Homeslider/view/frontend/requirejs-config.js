var config = {
    paths: {
        slick: 'Elsnertech_Homeslider/js/slick'
    },
    shim: {
        slick: {
            deps: ['jquery']
        }
    }
};